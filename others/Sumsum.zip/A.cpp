/*********************************************************************\
   |--\        ---       /\        |-----------| -----   /-------|    |
   |   \        |       /  \       |               |    /             |
   |    \       |      /    \      |               |   |              |
   |     \      |     /      \     |               |   |----|         |
   |      \     |    / ------ \    |-------|       |        |-----|   |
   |       \    |   /          \   |               |              |   |
   |        \   |  /            \  |               |              /   |
  ---        -------            ------           ----- |---------/    |
                                                                      |
    codeforces = nfssdq  ||  topcoder = nafis007                      |
    mail = nafis_sadique@yahoo.com || nfssdq@gmail.com                |
    IIT,Jahangirnagar University(41)                                  |
                                                                      |
**********************************************************************/

#include <bits/stdc++.h>
using namespace std;

#define xx         first
#define yy         second
#define pb         push_back
#define mp         make_pair
#define LL         long long
#define inf        INT_MAX/3
#define mod        1000000007ll
#define PI         acos(-1.0)
#define linf       (1ll<<60)-1
#define FOR(I,A,B) for(int I = (A); I < (B); ++I)
#define REP(I,N)   FOR(I,0,N)
#define ALL(A)     ((A).begin(), (A).end())
#define set0(ar)   memset(ar,0,sizeof ar)
#define vsort(v)   sort(v.begin(),v.end())
#define setinf(ar) memset(ar,126,sizeof ar)

//cout << fixed << setprecision(20) << p << endl;

template <class T> inline T bigmod(T p,T e,T M){
    LL ret = 1;
    for(; e > 0; e >>= 1){
        if(e & 1) ret = (ret * p) % M;
        p = (p * p) % M;
    } return (T)ret;
}
template <class T> inline T gcd(T a,T b){if(b==0)return a;return gcd(b,a%b);}
template <class T> inline T modinverse(T a,T M){return bigmod(a,M-2,M);}




LL ar[200001], sum[200001], sum2[200001];

pair < LL, LL > go1(int n, LL m){
    pair < LL, LL > ret = mp(0, 0);
    LL psum = 0, last = 1;
    for(int i = 1; i <= n; i++){
        psum += ar[i];
        while(psum > m){
            psum -= ar[last];
            last++;
        }

        if(last > i) continue;

        ret.yy += i - last + 1;
        ret.xx += sum[i] * ((LL)(i - last + 1));
        ret.xx += sum2[i-1];
        if(last-2 >= 0) ret.xx -= sum2[last-2];
    }

    return ret;
}

LL go(int n, LL v){
    if(v == 0) return 0;
    LL lo = 1, hi = n * 100, mid = (lo + hi) / 2ll;
    while(lo < mid){
        pair < LL, LL > p = go1(n, mid);
        if(p.yy >= v) hi = mid;
        else lo = mid + 1;
        mid = (lo + hi) / 2ll;
    }
    pair < LL, LL > p = go1(n, mid);
    if(p.yy < v) mid++;
    p = go1(n, mid - 1);

    return (p.xx + (v - p.yy)*mid);
}

int main() {
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    ios_base::sync_with_stdio(0); cin.tie(0);
    int T; cin >> T;
    FOR(ts, 1, T+1){
        int n, q; cin >> n >> q;
        FOR(i, 1, n+1) {
            cin >> ar[i];
            sum[i] = ar[i] + sum[i-1];
            sum2[i] = -sum[i] + sum2[i-1];
        }
        cout << "Case #" << ts << ":\n";
        cerr << "Case #" << ts << ":\n";
        while(q--){
            LL l, r; cin >> l >> r;
            cout << go(n, r) - go(n, l-1) << endl;

        }

    }
}

