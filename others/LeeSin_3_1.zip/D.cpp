#include <cstdio>
#include <algorithm>
#define N 505
#define M 1000000007
#define fi(a, b, c) for(int a = (b); a < (c); a++)
#define fd(a, b, c) for(int a = (b); a > (c); a--)
#define FI(a, b, c) for(int a = (b); a <= (c); a++)
#define FD(a, b, c) for(int a = (b); a >= (c); a--)
#define fe(a, b, c) for(int a = (b); a; a = c[a])
using namespace std;

int t, n, dp[N][N][N][2];
char s[N];

void add(int &a, int b){
	a += b;
	if(a > M) a -= M;
}

void solve(int tc){
	scanf("%s", s);
	for(n = 0; s[n]; n++);
	
	FI(i, 0, n) FI(j, 0, n / 2) FI(k, 0, n / 2) fi(l, 0, 2) dp[i][j][k][l] = 0;
	dp[0][0][0][0] = 1;
	
	FI(i, 1, n){
		FI(j, 0, n / 2) FI(k, 0, n / 2) fi(l, 0, 2){
			if(s[i - 1] == 'a'){
				if(!k) add(dp[i][j + 1][k][0], dp[i - 1][j][k][l]);
			}
			if(s[i - 1] == 'b'){
				if(j && !l) add(dp[i][j][k + 1][0], dp[i - 1][j][k][l]);
			}
			if(s[i - 1] == 'c'){
				if(j && k) add(dp[i][j - 1][k][1], dp[i - 1][j][k][l]);
			}
			if(s[i - 1] == 'd'){
				if(!j && k && l) add(dp[i][j][k - 1][1], dp[i - 1][j][k][l]);
			}
			add(dp[i][j][k][l], dp[i - 1][j][k][l]);
		}
		//FI(j, 0, n / 2) FI(k, 0, n / 2) fi(l, 0, 2) if(dp[i][j][k][l])
		//	printf("%d %d %d %d %d\n", i, j, k, l, dp[i][j][k][l]);
	}
	
	printf("Case #%d: %d\n", tc, dp[n][0][0][1]);
}

int main(){
	freopen("D-large.in", "r", stdin);
	freopen("D-large.out", "w+", stdout);
	scanf("%d", &t);
	FI(z, 1, t) solve(z);
	scanf("\n");
}
