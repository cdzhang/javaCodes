#include <iostream>
#include <cstdio>
#include <vector>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <map>
#include <queue>
#include <set>
using namespace std;
const int MOD = (int)1e9 + 7;
int dp[510][260][260][4];
int n;
char s[510];

int calc( char s[] ) {
	memset( dp, 0, sizeof(dp) );
	dp[0][0][0][0] = 1;

	for ( int i = 0; i < n; i ++ ) {
		for ( int j = 0; j <= n / 2; j ++ ) {
			for ( int k = 0; k <= n / 2; k ++ )	{
				if ( dp[i][j][k][0] + dp[i][j][k][1] + dp[i][j][k][2] + dp[i][j][k][3] == 0 ) {
					continue;
				}
				/*for ( int l = 0; l < 4; l ++ ) {
					if ( dp[i][j][k][l] ) cout <<i<<" "<<j<<" "<<k<<" "<<l<<" "<<dp[i][j][k][l]<<endl;
				}*/
				//cout <<i<<" "<<j<<" "<<k<<" "<<0<<" "<<dp[i][j][k][0]<<endl;

				// situation 0
				( dp[i + 1][j][k][0] += dp[i][j][k][0] ) %= MOD;
				if ( s[i] == 'a' ) {
					( dp[i + 1][j + 1][k][0] += dp[i][j][k][0] ) %= MOD;
				}
				if ( s[i] == 'b' && j ) {
					( dp[i + 1][j][k + 1][1] += dp[i][j][k][0] ) %= MOD;
				}

				//situation 1
				( dp[i + 1][j][k][1] += dp[i][j][k][1] ) %= MOD;
				if ( s[i] == 'b' ) {
					( dp[i + 1][j][k + 1][1] += dp[i][j][k][1] ) %= MOD;
				}
				if ( s[i] == 'c' ) {
					if ( j == 1 ) {
						( dp[i + 1][0][k][3] += dp[i][j][k][1] ) %= MOD;
					} else {
						( dp[i + 1][j - 1][k][2] += dp[i][j][k][1] ) %= MOD;
					}
				}

				//situation 2
				( dp[i + 1][j][k][2] += dp[i][j][k][2] ) %= MOD;
				if ( s[i] == 'c' ) {
					if ( j == 1 ) {
						( dp[i + 1][0][k][3] += dp[i][j][k][2] ) %= MOD;
					} else {
						( dp[i + 1][j - 1][k][2] += dp[i][j][k][2] ) %= MOD;
					}
				}

				//situation 3
				( dp[i + 1][j][k][3] += dp[i][j][k][3] ) %= MOD;
				if ( s[i] == 'd' ) {
					if ( k == 1 ) {
						( dp[i + 1][0][0][0] += dp[i][j][k][3] ) %= MOD;
					} else {
						( dp[i + 1][0][k - 1][3] += dp[i][j][k][3] ) %= MOD;
					}	
				}

			}
		}
	}

	//cout <<dp[5][1][1][1]<<endl;
	//cout <<dp[6][0][1][2]<<endl;
	//cout <<dp[7][0][0][0]<<endl;

	return dp[n][0][0][0];
}
int main() {
	freopen( "a.in", "r", stdin );
	freopen( "a.out", "w", stdout );

	int T;
	scanf( "%d", &T );

	for ( int cas = 1; cas <= T; cas ++ ) {
		scanf( "%s", s );
		n = strlen( s );

		int ret = calc( s );
		ret = ( ret - 1 + MOD ) % MOD;
		printf( "Case #%d: %d\n", cas, ret );
	}

	return 0;
}







