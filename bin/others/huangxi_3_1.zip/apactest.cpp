//============================================================================
// Name        : CF.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <bits/stdc++.h>
#define  RD(x)      scanf("%d", &x)
#define  REP(i, n)  for (int i=0; i<int(n); ++i)
#define  FOR(i, n)  for (int i=1; i<=int(n); ++i)
#define  pii        pair<int, int>
#define  piL        pair<int, long long>
#define  mp         make_pair
#define  pb         push_back
#define  whatis(x)  cout << #x << ": " << x << endl;
int dx[4] = {1, 0, -1, 0};
int dy[4] = {0, 1, 0, -1};
using namespace std;
#define  N   1234
#define  eps 1e-13
#define  pi  acos(-1.0)
#define  inf 0XFFFFFll
#define  mod 1000000007ll
#define  LL  long long
#define  ULL unsigned long long

inline void add(LL &x, LL y) {
	x = (x + y) % mod;
}
int n;
LL dp[2][4][N][N];

string s;

int Main() {

	freopen("D-large.in", "r", stdin);
//	freopen("out.txt", "w", stdout);
	ios_base::sync_with_stdio(0);
	int T; cin >> T;

	FOR(_T, T) {
		cout << "Case #" << _T << ": ";

		cin >> s;
		n = s.length();

		int m = n + 10;
		int cur = 0, to = 1;

		memset(dp, 0, sizeof dp);
		dp[cur][0][0+m][0+m] = 1;

		LL ans = 0;

		REP(i, n) {
			memset(dp[to], 0, sizeof dp[to]);
			REP(j, 4) {
				for (int p = -n; p <= n; p++) {
					for (int q = -n; q <= n; q++) {
						add(dp[to][j][p+m][q+m], dp[cur][j][p+m][q+m]);
					}
				}
			}
			if (s[i] == 'a') {
				add(dp[to][0][1+m][0+m], dp[cur][3][0+m][0+m]);
				for (int p = -n; p <= n; p++)
					add(dp[to][0][p+1+m][0+m], dp[cur][0][p+m][0+m]);
			} else if (s[i] == 'b') {
				for (int p = -n; p <= n; p++) {
					add(dp[to][1][p+m][1+m], dp[cur][0][p+m][0+m]);
					for (int q = -n; q <= n; q++) {
						add(dp[to][1][p+m][q+1+m], dp[cur][1][p+m][q+m]);
					}
				}
			} else if (s[i] == 'c') {
				for (int p = -n; p <= n; p++) {
					for (int q = -n; q <= n; q++) {
						add(dp[to][2][p-1+m][q+m], dp[cur][1][p+m][q+m]);
						add(dp[to][2][p-1+m][q+m], dp[cur][2][p+m][q+m]);
					}
				}
			} else {
				for (int q = -n; q <= n; q++) {
					add(dp[to][3][0+m][q-1+m], dp[cur][2][0+m][q+m]);
					add(dp[to][3][0+m][q-1+m], dp[cur][3][0+m][q+m]);
				}
			}

			swap(cur, to);
		}

		add(ans, dp[cur][3][0+m][0+m]);
		cout << ans << endl;
	}


	return 0;
}

int main() {
	return Main();
}
